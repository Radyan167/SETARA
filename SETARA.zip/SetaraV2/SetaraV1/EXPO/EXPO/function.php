<?php
// Function to establish a database connection
function get_database_connection() {
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $db_name = 'setara';

    $conn = new mysqli($host, $username, $password, $db_name);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Function to fetch article data based on a search query
function get_artikel_data($question) {
    $conn = get_database_connection();
    $sql = "SELECT * FROM tari_articles WHERE nama LIKE ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        throw new Exception("Preparation failed: " . $conn->error);
    }

    $like_question = '%' . $question . '%';
    $stmt->bind_param("s", $like_question);

    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        throw new Exception("Execution failed: " . $stmt->error);
    }

    $result = $stmt->get_result();
    $artikel_data = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $artikel_data[] = $row;
        }
    }

    $stmt->close();
    $conn->close();

    return $artikel_data;
}
?>
