document.addEventListener("DOMContentLoaded", function () {
    // Bar chart for Event Categories by Month
    const ctxBar = document.getElementById("eventCategoryChart").getContext("2d");
    const eventCategoryChart = new Chart(ctxBar, {
        type: "bar",
        data: {
            labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
            datasets: [
                {
                    label: "Tradisional",
                    data: [12, 19, 3, 5, 2, 3, 10, 7, 8, 6, 4, 2],
                    backgroundColor: "rgba(75, 192, 192, 0.2)",
                    borderColor: "rgba(75, 192, 192, 1)",
                    borderWidth: 1,
                },
                {
                    label: "Modern",
                    data: [8, 11, 13, 15, 20, 18, 14, 12, 9, 5, 3, 4],
                    backgroundColor: "rgba(54, 162, 235, 0.2)",
                    borderColor: "rgba(54, 162, 235, 1)",
                    borderWidth: 1,
                },
                {
                    label: "Campuran",
                    data: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
                    backgroundColor: "rgba(255, 206, 86, 0.2)",
                    borderColor: "rgba(255, 206, 86, 1)",
                    borderWidth: 1,
                },
            ],
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                },
            },
        },
    });

    // Pie chart for Event Types
    const ctxPie = document.getElementById("eventTypeChart").getContext("2d");
    const eventTypeChart = new Chart(ctxPie, {
        type: "pie",
        data: {
            labels: ["Tunggal", "Berpasangan", "Kelompok", "Massal"],
            datasets: [
                {
                    label: "Event Types",
                    data: [10, 20, 30, 40],
                    backgroundColor: [
                        "rgba(255, 99, 132, 0.2)",
                        "rgba(54, 162, 235, 0.2)",
                        "rgba(255, 206, 86, 0.2)",
                        "rgba(75, 192, 192, 0.2)",
                    ],
                    borderColor: [
                        "rgba(255, 99, 132, 1)",
                        "rgba(54, 162, 235, 1)",
                        "rgba(255, 206, 86, 1)",
                        "rgba(75, 192, 192, 1)",
                    ],
                    borderWidth: 1,
                },
            ],
        },
    });
});
