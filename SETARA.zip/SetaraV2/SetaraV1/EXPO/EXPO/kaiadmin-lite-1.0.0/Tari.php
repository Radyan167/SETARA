<?php
$host = 'localhost'; // Host name
$username = 'root'; // Mysql username
$password = ''; // Mysql password
$db_name = 'setara'; // Database name

// Connect to server and select database.
$conn = new mysqli($host, $username, $password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['addTari'])) {
    $nama = $_POST['nama'];
    $asal = $_POST['asal'];
    $tempo_musik = $_POST['tempo_musik'];
    $tujuan = $_POST['tujuan'];
    $jenis_tari = $_POST['jenis_tari'];
    $tema_tari = $_POST['tema_tari'];

    $stmt = $conn->prepare("INSERT INTO data_tari (nama, asal, tempo_musik, tujuan_tari, jenis_tari, tema_tari) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $nama, $asal, $tempo_musik, $tujuan, $jenis_tari, $tema_tari);
    $stmt->execute();
    $stmt->close();
    header("Location: " . $_SERVER['PHP_SELF']); // Reload the page to see the new entry
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['deleteTari'])) {
    $id = $_POST['id'];
    $stmt = $conn->prepare("DELETE FROM data_tari WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: " . $_SERVER['PHP_SELF']); // Reload the page to see the updated list
    exit;
}

function getAllTari() {
    global $conn;
    $sql = "SELECT * FROM data_tari";
    $result = $conn->query($sql);
    $tari = [];
    while ($row = $result->fetch_assoc()) {
        $tari[] = $row;
    }
    return $tari;
}

$tari = getAllTari();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Data Tari</title>
    <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
    <link rel="icon" href="assets/img/kaiadmin/favicon.ico" type="image/x-icon" />

    <!-- Fonts and icons -->
    <script src="assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
        WebFont.load({
            google: { families: ["Public Sans:300,400,500,600,700"] },
            custom: {
                families: [
                    "Font Awesome 5 Solid",
                    "Font Awesome 5 Regular",
                    "Font Awesome 5 Brands",
                    "simple-line-icons",
                ],
                urls: ["assets/css/fonts.min.css"],
            },
            active: function () {
                sessionStorage.fonts = true;
            },
        });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/plugins.min.css" />
    <link rel="stylesheet" href="assets/css/kaiadmin.min.css" />
    <link rel="stylesheet" href="Tari.css"/>
    <!-- DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar" data-background-color="dark">
            <div class="sidebar-logo">
                <div class="logo-header" data-background-color="dark">
                <a href="\SetaraV2\SetaraV1\EXPO\EXPO\index1.php" class="logo">
                <img src="assets/img/kaiadmin/logo_light.svg" alt="navbar brand" class="navbar-brand" height="20" />
                    </a>
                    <div class="nav-toggle">
                        <button class="btn btn-toggle toggle-sidebar">
                            <i class="gg-menu-right"></i>
                        </button>
                        <button class="btn btn-toggle sidenav-toggler">
                            <i class="gg-menu-left"></i>
                        </button>
                    </div>
                    <button class="topbar-toggler more">
                        <i class="gg-more-vertical-alt"></i>
                    </button>
                </div>
            </div>
            <div class="sidebar-wrapper scrollbar scrollbar-inner">
                <div class="sidebar-content">
                    <ul class="nav nav-secondary">
                        <li class="nav-item active">
                            <a href="index.php" class="collapsed" aria-expanded="false">
                                <i class="fas fa-home"></i>
                                <p>Dashboard</p>
                            </a>
                            <div class="collapse" id="dashboard"></div>
                        </li>
                        <li class="nav-section">
                            <span class="sidebar-mini-icon">
                                <i class="fa fa-ellipsis-h"></i>
                            </span>
                            <h4 class="text-section">Components</h4>
                        </li>
                        <li class="nav-item">
                            <a href="groq.php">
                                <i class="fas fa-th-list"></i>
                                <p>Bertanya</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="Event.php">
                                <i class="fas fa-pen-square"></i>
                                <p>Event</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="Tari.php">
                                <i class="fas fa-table"></i>
                                <p>Tari</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="article.php">
                                <i class="fas fa-table"></i>
                                <p>Article</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- End Sidebar -->

        <div class="main-panel">
            <div class="main-header">
                <div class="main-header-logo">
                    <div class="logo-header" data-background-color="dark">
                        <a href="index.html" class="logo">
                            <img src="assets/img/kaiadmin/logo_light.svg" alt="navbar brand" class="navbar-brand" height="20" />
                        </a>
                        <div class="nav-toggle">
                            <button class="btn btn-toggle toggle-sidebar">
                                <i class="gg-menu-right"></i>
                            </button>
                            <button class="btn btn-toggle sidenav-toggler">
                                <i class="gg-menu-left"></i>
                            </button>
                        </div>
                        <button class="topbar-toggler more">
                            <i class="gg-more-vertical-alt"></i>
                        </button>
                    </div>
                </div>
                <nav class="navbar navbar-header navbar-header-transparent navbar-expand-lg border-bottom">
                    <div class="container-fluid">
                        <ul class="navbar-nav topbar-nav ms-md-auto align-items-center">
                            <li class="nav-item topbar-user dropdown hidden-caret">
                                <a class="dropdown-toggle profile-pic" data-bs-toggle="dropdown" href="#" aria-expanded="false">
                                    <div class="avatar-sm">
                                        <img src="assets/img/profile.jpg" alt="..." class="avatar-img rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-user animated fadeIn">
                                    <div class="dropdown-user-scroll scrollbar-outer">
                                        <li>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">My Profile</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Account Setting</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Logout</a>
                                        </li>
                                    </div>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>

            <div class="container">
                <div class="page-inner">
                    <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2 pb-4">
                        <div>
                            <h3 class="fw-bold mb-3">Dashboard</h3>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">Tambah Tari</div>
                                </div>
                                <div class="card-body">
                                    <form method="POST" action="">
                                        <div class="form-group">
                                            <label for="nama">Nama Tari</label>
                                            <input type="text" class="form-control" id="nama" name="nama" placeholder="Enter nama" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="asal">Asal</label>
                                            <select class="form-control" id="asal" name="asal">
                                                <option value="Jawa">Jawa</option>
                                                <option value="Sumatra">Sumatra</option>
                                                <option value="Kalimantan">Kalimantan</option>
                                                <option value="Sulawesi">Sulawesi</option>
                                                <option value="Bali">Bali</option>
                                                <option value="Nusa Tenggara">Nusa Tenggara</option>
                                                <option value="Maluku">Maluku</option>
                                                <option value="Papua">Papua</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="tempo_musik">Tempo Musik</label>
                                            <select class="form-control" id="tempo_musik" name="tempo_musik">
                                                <option value="Cepat">Cepat</option>
                                                <option value="Sedang">Sedang</option>
                                                <option value="Lambat">Lambat</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="tujuan">Tujuan</label>
                                            <select class="form-control" id="tujuan" name="tujuan">
                                                <option value="Upacara">Upacara</option>
                                                <option value="Hiburan">Hiburan</option>
                                                <option value="Pendidikan">Pendidikan</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="jenis_tari">Jenis Tari</label>
                                            <select class="form-control" id="jenis_tari" name="jenis_tari">
                                                <option value="Tunggal">Tunggal</option>
                                                <option value="Berkelompok">Berkelompok</option>
                                                <option value="Massal">Massal</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="tema_tari">Tema Tari</label>
                                            <select class="form-control" id="tema_tari" name="tema_tari">
                                                <option value="Literal">Literal</option>
                                                <option value="Non-Literal">Non-Literal</option>
                                            </select>
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="addTari">Tambah Tari</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">Data Tari</div>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="tariTable" class="table">
                                            <thead>
                                                <tr>
                                                    <th>Nama</th>
                                                    <th>Asal</th>
                                                    <th>Tempo Musik</th>
                                                    <th>Tujuan Tari</th>
                                                    <th>Jenis Tari</th>
                                                    <th>Tema Tari</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($tari as $item) { ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($item['nama']); ?></td>
                                                        <td><?php echo htmlspecialchars($item['asal']); ?></td>
                                                        <td><?php echo htmlspecialchars($item['tempo_musik']); ?></td>
                                                        <td><?php echo htmlspecialchars($item['tujuan_tari']); ?></td>
                                                        <td><?php echo htmlspecialchars($item['jenis_tari']); ?></td>
                                                        <td><?php echo htmlspecialchars($item['tema_tari']); ?></td>
                                                        <td>
                                                            <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this item?');">
                                                                <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                                                                <button type="submit" name="deleteTari" class="btn btn-danger btn-sm">Delete</button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Further content and footer omitted for brevity -->
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS Files -->
    <script src="assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="assets/js/core/popper.min.js"></script>
    <script src="assets/js/core/bootstrap.min.js"></script>

    <!-- jQuery Scrollbar -->
    <script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

    <!-- DataTables JS -->
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>

    <!-- Kaiadmin JS -->
    <script src="assets/js/kaiadmin.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#tariTable').DataTable();
        });
    </script>
</body>
</html>
