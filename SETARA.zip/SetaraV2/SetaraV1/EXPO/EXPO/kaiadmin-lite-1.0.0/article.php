
<?php
$host = 'localhost'; // Host name
$username = 'root'; // Mysql username
$password = ''; // Mysql password
$db_name = 'setara'; // Database name

// Connect to server and select database.
$conn = new mysqli($host, $username, $password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function getAllTariArticles() {
    global $conn;
    $sql = "SELECT * FROM tari_articles";
    $result = $conn->query($sql);
    $articles = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $articles[] = $row;
        }
    }
    return $articles;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['addArticle'])) {
        $nama = $_POST['nama'];
        $asal = $_POST['asal'];
        $tempo_musik = $_POST['tempo_musik'];
        $tujuan_tari = $_POST['tujuan_tari'];
        $jenis_tari = $_POST['jenis_tari'];
        $tema_tari = $_POST['tema_tari'];
        $deskripsi = $_POST['deskripsi'];

        $stmt = $conn->prepare("INSERT INTO tari_articles (nama, asal, tempo_musik, tujuan_tari, jenis_tari, tema_tari, deskripsi) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $nama, $asal, $tempo_musik, $tujuan_tari, $jenis_tari, $tema_tari, $deskripsi);
        $stmt->execute();
        $stmt->close();
        header("Location: " . $_SERVER['PHP_SELF']); // Reload the page to see the new article
        exit;
    }

    if (isset($_POST['deleteArticle'])) {
        $article_id = $_POST['article_id'];
        $stmt = $conn->prepare("DELETE FROM tari_articles WHERE id = ?");
        $stmt->bind_param("i", $article_id);
        $stmt->execute();
        $stmt->close();
        header("Location: " . $_SERVER['PHP_SELF']); // Reload the page to see the updated list
        exit;
    }
}

$articles = getAllTariArticles();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Article Tari</title>
    <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
    <link rel="icon" href="assets/img/kaiadmin/favicon.ico" type="image/x-icon" />

    <!-- Fonts and icons -->
    <script src="assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
      WebFont.load({
        google: { families: ["Public Sans:300,400,500,600,700"] },
        custom: {
          families: [
            "Font Awesome 5 Solid",
            "Font Awesome 5 Regular",
            "Font Awesome 5 Brands",
            "simple-line-icons",
          ],
          urls: ["assets/css/fonts.min.css"],
        },
        active: function () {
          sessionStorage.fonts = true;
        },
      });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/plugins.min.css" />
    <link rel="stylesheet" href="assets/css/kaiadmin.min.css" />

    <!-- DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar" data-background-color="dark">
            <div class="sidebar-logo">
                <!-- Logo Header -->
                <div class="logo-header" data-background-color="dark">
                <a href="\SetaraV2\SetaraV1\EXPO\EXPO\index1.php" class="logo">
                <img src="assets/img/kaiadmin/logo_light.svg" alt="navbar brand" class="navbar-brand" height="20" />
                    </a>
                    <div class="nav-toggle">
                        <button class="btn btn-toggle toggle-sidebar">
                            <i class="gg-menu-right"></i>
                        </button>
                        <button class="btn btn-toggle sidenav-toggler">
                            <i class="gg-menu-left"></i>
                        </button>
                    </div>
                    <button class="topbar-toggler more">
                        <i class="gg-more-vertical-alt"></i>
                    </button>
                </div>
                <!-- End Logo Header -->
            </div>
            <div class="sidebar-wrapper scrollbar scrollbar-inner">
                <div class="sidebar-content">
                    <ul class="nav nav-secondary">
                        <li class="nav-item active">
                            <a href="index.php" class="collapsed" aria-expanded="false">
                                <i class="fas fa-home"></i>
                                <p>Dashboard</p>
                            </a>
                        </li>
                        <li class="nav-section">
                            <span class="sidebar-mini-icon">
                                <i class="fa fa-ellipsis-h"></i>
                            </span>
                            <h4 class="text-section">Components</h4>
                        </li>
                        <li class="nav-item">
                            <div class="collapse" id="base">
                                <ul class="nav nav-collapse">
                                    <li>
                                        <a href="components/avatars.html">
                                            <span class="sub-item">Avatars</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="components/buttons.html">
                                            <span class="sub-item">Buttons</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="components/gridsystem.html">
                                            <span class="sub-item">Grid System</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="components/panels.html">
                                            <span class="sub-item">Panels</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="components/sweetalert.html">
                                            <span class="sub-item">Sweet Alert</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="components/font-awesome-icons.html">
                                            <span class="sub-item">Font Awesome Icons</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="components/simple-line-icons.html">
                                            <span class="sub-item">Simple Line Icons</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="components/typography.html">
                                            <span class="sub-item">Typography</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a href="groq.php">
                                <i class="fas fa-th-list"></i>
                                <p>Bertanya</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="Event.php">
                                <i class="fas fa-pen-square"></i>
                                <p>Event</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="Tari.php">
                                <i class="fas fa-table"></i>
                                <p>Tari</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="article.php">
                                <i class="fas fa-table"></i>
                                <p>Article</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- End Sidebar -->

        <div class="main-panel">
            <div class="main-header">
                <div class="main-header-logo">
                    <!-- Logo Header -->
                    <div class="logo-header" data-background-color="dark">
                        <a href="index.html" class="logo">
                            <img src="assets/img/kaiadmin/logo_light.svg" alt="navbar brand" class="navbar-brand" height="20" />
                        </a>
                        <div class="nav-toggle">
                            <button class="btn btn-toggle toggle-sidebar">
                                <i class="gg-menu-right"></i>
                            </button>
                            <button class="btn btn-toggle sidenav-toggler">
                                <i class="gg-menu-left"></i>
                            </button>
                        </div>
                        <button class="topbar-toggler more">
                            <i class="gg-more-vertical-alt"></i>
                        </button>
                    </div>
                    <!-- End Logo Header -->
                </div>
                <!-- Navbar Header -->
                <nav class="navbar navbar-header navbar-header-transparent navbar-expand-lg border-bottom">
                    <div class="container-fluid">
                        <ul class="navbar-nav topbar-nav ms-md-auto align-items-center">
                           

 <li class="nav-item topbar-user dropdown hidden-caret">
                                <a class="dropdown-toggle profile-pic" data-bs-toggle="dropdown" href="#" aria-expanded="false">
                                    <div class="avatar-sm">
                                        <img src="assets/img/profile.jpg" alt="..." class="avatar-img rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-user animated fadeIn">
                                    <div class="dropdown-user-scroll scrollbar-outer">
                                        <li>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">My Profile</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Account Setting</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Logout</a>
                                        </li>
                                    </div>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Navbar -->
            </div>

            <div class="container">
                <div class="page-inner">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">Tambah Artikel Tari</div>
                                </div>
                                <div class="card-body">
                                    <form method="POST" action="">
                                        <div class="form-group">
                                            <label for="nama">Nama</label>
                                            <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan nama tari" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="asal">Asal</label>
                                            <select class="form-control" id="asal" name="asal">
                                                <option value="Jawa">Jawa</option>
                                                <option value="Sumatra">Sumatra</option>
                                                <option value="Kalimantan">Kalimantan</option>
                                                <option value="Sulawesi">Sulawesi</option>
                                                <option value="Bali">Bali</option>
                                                <option value="Nusa Tenggara">Nusa Tenggara</option>
                                                <option value="Maluku">Maluku</option>
                                                <option value="Papua">Papua</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="tempo_musik">Tempo Musik</label>
                                            <select class="form-control" id="tempo_musik" name="tempo_musik">
                                                <option value="Cepat">Cepat</option>
                                                <option value="Sedang">Sedang</option>
                                                <option value="Lambat">Lambat</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="tujuan_tari">Tujuan Tari</label>
                                            <select class="form-control" id="tujuan_tari" name="tujuan_tari">
                                                <option value="Upacara">Upacara</option>
                                                <option value="Hiburan">Hiburan</option>
                                                <option value="Pendidikan">Pendidikan</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="jenis_tari">Jenis Tari</label>
                                            <select class="form-control" id="jenis_tari" name="jenis_tari">
                                                <option value="Berkelompok">Berkelompok</option>
                                                <option value="Tunggal">Tunggal</option>
                                                <option value="Massal">Massal</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="tema_tari">Tema Tari</label>
                                            <select class="form-control" id="tema_tari" name="tema_tari">
                                                <option value="Literal">Literal</option>
                                                <option value="Non Literal">Non Literal</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="deskripsi">Deskripsi</label>
                                            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" placeholder="Masukkan deskripsi tari" required></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="addArticle">Tambah Artikel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">Daftar Artikel Tari</div>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="articleTable" class="table">
                                            <thead>
                                                <tr>
                                                    <th>Nama</th>
                                                    <th>Asal</th>
                                                    <th>Tempo Musik</th>
                                                    <th>Tujuan Tari</th>
                                                    <th>Jenis Tari</th>
                                                    <th>Tema Tari</th>
                                                    <th>Deskripsi</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if (is_array($articles) && count($articles) > 0): ?>
                                                    <?php foreach ($articles as $article) { ?>
                                                        <tr>
                                                            <td><?php echo htmlspecialchars($article['nama']); ?></td>
                                                            <td><?php echo htmlspecialchars($article['asal']); ?></td>
                                                            <td><?php echo htmlspecialchars($article['tempo_musik']); ?></td>
                                                            <td><?php echo htmlspecialchars($article['tujuan_tari']); ?></td>
                                                            <td><?php echo htmlspecialchars($article['jenis_tari']); ?></td>
                                                            <td><?php echo htmlspecialchars($article['tema_tari']); ?></td>
                                                            <td><?php echo htmlspecialchars($article['deskripsi']); ?></td>
                                                            <td>
                                                                <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this article?');">
                                                                    <input type="hidden" name="article_id" value="<?php echo $article['id']; ?>">
                                                                    <button type="submit" name="deleteArticle" class="btn btn-danger btn-sm">Delete</button>
                                                                </form>
                                                            </td>
                                                        </tr>
                                                    <?php } ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="8" class="text-center">No articles found</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Further content and footer omitted for brevity -->
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS Files -->
    <script src="assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="assets/js/core/popper.min.js"></script>
    <script src="assets/js/core/bootstrap.min.js"></script>

    <!-- jQuery Scrollbar -->
    <script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

    <!-- Chart JS -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- DataTables JS -->
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>

    <!-- Kaiadmin JS -->
    <script src="assets/js/kaiadmin.min.js"></script>

    <!-- Kaiadmin DEMO methods, don't include it in your project -->
    <script src="assets/js/setting-demo.js"></script>
    <script src="Tari.js"></script>
    <script>
        $(document).ready(function() {
            $('#articleTable').DataTable();
        });
    </script>
</body>
</html>
```