<?php
header('Content-Type: application/json');

// Database connection details
$host = "localhost";
$user = "root";
$password = "";
$database = "setara";

// Create connection
$mysqli = new mysqli($host, $user, $password, $database);

// Check connection
if ($mysqli->connect_error) {
    die(json_encode(['count' => 0, 'error' => 'Connection failed: ' . $mysqli->connect_error]));
}

// Query to count the number of entries in the data_tari table
$query = "SELECT COUNT(*) as count FROM data_tari";
$result = $mysqli->query($query);

// Fetch the result
if ($result) {
    $row = $result->fetch_assoc();
    echo json_encode(['count' => $row['count']]);
} else {
    echo json_encode(['count' => 0, 'error' => 'Query failed: ' . $mysqli->error]);
}

// Close the connection
$mysqli->close();
?>
