<?php
include 'koneksi.php';

// Query database
$sql = "SELECT jenis, COUNT(*) as jumlah FROM data_event_tari GROUP BY jenis";
$result = $conn->query($sql);

$data = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Mengirim data sebagai JSON
echo json_encode($data);

// Tutup koneksi
$conn->close();
?>
