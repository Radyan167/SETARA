<?php
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'setara';

$conn = new mysqli($host, $username, $password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT jenis_tari, COUNT(*) as jumlah FROM data_tari GROUP BY jenis_tari";
$result = $conn->query($sql);

$jenis_tari = [];
while ($row = $result->fetch_assoc()) {
    $jenis_tari[] = $row;
}

echo json_encode($jenis_tari);
?>
