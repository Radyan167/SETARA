<?php
include 'koneksi.php';

// Query database
$sql = "SELECT tempo_musik, COUNT(*) as jumlah FROM data_tari GROUP BY tempo_musik";
$result = $conn->query($sql);

$data = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Mengirim data sebagai JSON
echo json_encode($data);

// Tutup koneksi
$conn->close();
?>
