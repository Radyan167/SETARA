<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "setara";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to get data from the database
function get_tari_data() {
    global $conn;
    $sql = "SELECT * FROM data_tari";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $tari_data = array();
        while($row = $result->fetch_assoc()) {
            $tari_data[] = $row;
        }
        return $tari_data;
    } else {
        return array();
    }
}

// Function to get event data from the database
function get_event_data() {
    global $conn;
    $sql = "SELECT * FROM data_event_tari";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $event_data = array();
        while($row = $result->fetch_assoc()) {
            $event_data[] = $row;
        }
        return $event_data;
    } else {
        return array();
    }
}

// Function to predict future trends (dummy implementation)
function predict_trends($tari_data, $event_data) {
    // Implement your trend prediction logic here
    // This is a dummy implementation
    $trends = array(
        "Tari Jaipong" => "High popularity",
        "Tari Saman" => "Moderate popularity",
        "Tari Kecak" => "Increasing popularity"
    );
    return $trends;
}
?>
