<?php
header('Content-Type: application/json');

$data = [
    'jenisTari' => [
        ['label' => 'Tunggal', 'data' => 30],
        ['label' => 'Berpasangan', 'data' => 20],
        ['label' => 'Kelompok', 'data' => 25],
        ['label' => 'Massal', 'data' => 25],
    ],
    'tempoMusik' => [
        ['label' => 'Lambat', 'data' => 40],
        ['label' => 'Sedang', 'data' => 35],
        ['label' => 'Cepat', 'data' => 25],
    ],
    'tujuanTari' => [
        ['label' => 'Upacara', 'data' => 25],
        ['label' => 'Hiburan', 'data' => 30],
        ['label' => 'Pendidikan', 'data' => 20],
        ['label' => 'Pertunjukan', 'data' => 25],
    ],
    'temaTari' => [
        ['label' => 'Literal', 'data' => 60],
        ['label' => 'Non-Literal', 'data' => 40],
    ],
    'kategoriTari' => [
        ['label' => 'Tradisional', 'data' => 45],
        ['label' => 'Mix', 'data' => 30],
        ['label' => 'Modern', 'data' => 25],
    ],
];

echo json_encode($data);
?>
