document.addEventListener('DOMContentLoaded', function () {
    // Data for the charts
    var jenisTariData = {
        labels: [],
        datasets: [{
            data: [],
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
        }]
    };

    var tempoMusikData = {
        labels: [],
        datasets: [{
            data: [],
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
        }]
    };

    var tujuanTariData = {
        labels: [],
        datasets: [{
            data: [],
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
        }]
    };

    var temaTariData = {
        labels: [],
        datasets: [{
            label: 'Tema Tari',
            data: [],
            backgroundColor: ['#FF6384', '#36A2EB'],
        }]
    };

    var eventTariData = {
        labels: [],
        datasets: [{
            label: 'Jumlah Event',
            data: [],
            backgroundColor: ['#FF6384', '#36A2EB'],
            borderColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
            borderWidth: 1
        }]
    };

    var asalTariData = {
        labels: [],
        datasets: [{
            label: 'Asal Tari',
            data: [],
            backgroundColor: ['#FF6384', '#36A2EB'],
        }]
    };

    // Fetch data for jenis tari
    fetch('fetch_jenis_tari.php')
        .then(response => response.json())
        .then(data => {
            console.log('Jenis Tari Data:', data);
            const labels = data.map(item => item.jenis_tari);
            const counts = data.map(item => item.jumlah);

            jenisTariData.labels = labels;
            jenisTariData.datasets[0].data = counts;

            var ctx1 = document.getElementById('jenisTariChart').getContext('2d');
            new Chart(ctx1, {
                type: 'pie',
                data: jenisTariData,
            });
        })
        .catch(error => console.error('Error fetching jenis tari data:', error));

    // Fetch data for tempo musik
    fetch('fetch_tema_musik.php')
        .then(response => response.json())
        .then(data => {
            console.log('Tempo Musik Data:', data);
            const labels = data.map(item => item.tempo_musik);
            const counts = data.map(item => item.jumlah);

            tempoMusikData.labels = labels;
            tempoMusikData.datasets[0].data = counts;

            var ctx2 = document.getElementById('tempoMusikChart').getContext('2d');
            new Chart(ctx2, {
                type: 'pie',
                data: tempoMusikData,
            });
        })
        .catch(error => console.error('Error fetching tema musik data:', error));

    // Fetch data for tujuan tari
    fetch('fetch_tujuan_tari.php')
        .then(response => response.json())
        .then(data => {
            console.log('Tujuan Tari Data:', data);
            const labels = data.map(item => item.tujuan_tari);
            const counts = data.map(item => item.jumlah);

            tujuanTariData.labels = labels;
            tujuanTariData.datasets[0].data = counts;

            var ctx3 = document.getElementById('tujuanTariChart').getContext('2d');
            new Chart(ctx3, {
                type: 'pie',
                data: tujuanTariData,
            });
        })
        .catch(error => console.error('Error fetching tujuan tari data:', error));

    // Fetch data for tema tari
    fetch('fetch_tema_tari.php')
        .then(response => response.json())
        .then(data => {
            console.log('Tema Tari Data:', data);
            const labels = data.map(item => item.tema_tari);
            const counts = data.map(item => item.jumlah);

            temaTariData.labels = labels;
            temaTariData.datasets[0].data = counts;

            var ctx4 = document.getElementById('temaTariChart').getContext('2d');
            new Chart(ctx4, {
                type: 'bar',
                data: temaTariData,
            });
        })
        .catch(error => console.error('Error fetching tema tari data:', error));

    // Fetch data for event tari
    fetch('fetch_event_tari.php')
        .then(response => response.json())
        .then(data => {
            console.log('Event Tari Data:', data);
            const labels = data.map(item => item.jenis);
            const counts = data.map(item => item.jumlah);

            eventTariData.labels = labels;
            eventTariData.datasets[0].data = counts;

            var ctx5 = document.getElementById('eventtari').getContext('2d');
            new Chart(ctx5, {
                type: 'bar',
                data: eventTariData,
            });
        })
        .catch(error => console.error('Error fetching event tari data:', error));

    // Fetch data for asal tari
    fetch('fetch_asal_tari.php')
        .then(response => response.json())
        .then(data => {
            console.log('Asal Tari Data:', data);
            const labels = data.map(item => item.asal_tari);
            const counts = data.map(item => item.jumlah);

            asalTariData.labels = labels;
            asalTariData.datasets[0].data = counts;

            var ctx6 = document.getElementById('asaltarichart').getContext('2d');
            new Chart(ctx6, {
                type: 'bar',
                data: asalTariData,
            });
        })
        .catch(error => console.error('Error fetching asal tari data:', error));
});
