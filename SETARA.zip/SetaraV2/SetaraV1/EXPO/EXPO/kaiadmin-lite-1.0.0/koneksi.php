<?php
// Database configuration
$servername = "localhost"; // biasanya 'localhost'
$username = "root"; // username database Anda
$password = ""; // password database Anda
$dbname = "setara"; // ganti dengan nama database Anda

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
